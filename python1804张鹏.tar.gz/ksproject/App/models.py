import hashlib

from django.db import models

# Create your models here.
class HomeWheel(models.Model):
    img = models.CharField(max_length=256)
    class Meta:
        db_table = 'vm_wheel'

class HomeNav(models.Model):
    postid = models.ImageField(default=1)
    title = models.CharField(max_length=128)
    image = models.CharField(max_length=256)
    duration = models.ImageField(18)

    class Meta:
        db_table = 'vm_nav'


class UserModel(models.Model):
    u_name = models.CharField(max_length=16, unique=True)
    u_password = models.CharField(max_length=128)
    u_email = models.CharField(max_length=64, unique=True)
    u_icon = models.ImageField(upload_to='icons')
    is_delete = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)

    # 设置密码
    def set_password(self, password):
        self.u_password = self.generate_hash(password)

    # 对密码进行哈希算法
    def generate_hash(self, password):
        sha = hashlib.sha512()
        sha.update(password.encode('utf-8'))

        return sha.hexdigest()

    # 检验密码是否一致
    def check_password(self, password):
        return self.u_password == self.generate_hash(password)

    class Meta:
        db_table = 'vm_user'
