from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect

# Create your views here.
from django.urls import reverse

from App.models import UserModel, HomeWheel, HomeNav


def index(request):
    return HttpResponse('项目创建成功')


def home(request):
    wheels = HomeWheel.objects.all()
    navs = HomeNav.objects.all()
    data = {
        'title': '首页',
        "wheels": wheels,
        'navs':navs,
    }
    return render(request, 'home.html', data)


def home_logined(request):
    is_login = False

    user_id = request.session.get('user_id')

    data = {
        'title': '我的',
        'is_login': is_login,
    }

    if user_id:
        is_login = True
        user = UserModel.objects.get(pk=user_id)
        data['is_login'] = is_login
        data['user_icon'] = '/static/upload/' + user.u_icon.url
        data['username'] = user.u_name
    return render(request, 'home_logined_collected.html', context=data)


def home_logined_collected(request):
    return render(request, 'home_logined_collected.html')


def login(request):
    if request.method == "GET":

        msg = request.session.get('msg')

        data = {
            'title': '用户登录',
            'msg': msg
        }

        return render(request, 'login.html', context=data)
    elif request.method == "POST":

        username = request.POST.get('u_name')
        password = request.POST.get('u_password')

        users = UserModel.objects.filter(u_name=username)

        if users.exists():
            user = users.first()

            if user.check_password(password):
                if not user.is_active:
                    request.session['msg'] = '用户未激活'
                    return redirect(reverse('axf:user_login'))

                request.session['user_id'] = user.id
                return redirect(reverse('axf:mine'))
            else:
                request.session['msg'] = '密码错误'
                # 密码错误
                return redirect(reverse('axf:login'))
        else:
            request.session['msg'] = '用户不存在'
            # 用户不存在
            return redirect(reverse('axf:login'))

    return render(request, 'login.html')


def register(request):
    if request.method == "GET":

        data = {
            "title": '用户注册'
        }
        return render(request, 'register.html', context=data)
    elif request.method == "POST":

        username = request.POST.get('u_name')
        password = request.POST.get('u_password')
        email = request.POST.get('u_email')
        icon = request.FILES.get('u_icon')

        print(password)

        user = UserModel()

        user.u_name = username
        user.u_email = email
        user.u_icon = icon

        user.set_password(password)

        user.save()

        request.session['user_id'] = user.id

        # send_mail_learn(username, email, user.id)

        return redirect(reverse('app:home_logined'))

    return render(request, 'register.html')

def check_user(request):
    username = request.GET.get("u_name")
    # 0 或 1
    users = UserModel.objects.filter(u_name=username)

    data = {
        'status': '200',
        'msg': 'ok'
    }

    if users.exists():
        # 801 代表用户已存在
        data['status'] = '801'
        data['msg'] = 'already exists'
    else:
        data['msg'] = 'can use'

    return JsonResponse(data)

def check_email(request):
    email = request.GET.get('u_email')

    users = UserModel.objects.filter(u_email=email)

    data = {
        'status': '200',
        'msg': 'ok'
    }

    if users.exists():
        data['status'] = '802'
        data['msg'] = 'email already exists'
    else:
        data['msg'] = 'can use'

    return JsonResponse(data)



def check_newname(request):
    newname = request.GET.get("new_name")
    # 0 或 1
    users = UserModel.objects.filter(u_name=newname)

    data = {
        'status': '200',
        'msg': 'ok'
    }

    if users.exists():
        # 801 代表用户已存在
        data['status'] = '801'
        data['msg'] = 'already exists'
    else:
        data['msg'] = 'can use'

    return JsonResponse(data)

def check_newemail(request):
    newemail = request.GET.get('new_email')

    users = UserModel.objects.filter(u_email=newemail)

    data = {
        'status': '200',
        'msg': 'ok'
    }

    if users.exists():
        data['status'] = '802'
        data['msg'] = 'email already exists'
    else:
        data['msg'] = 'can use'

    return JsonResponse(data)



def userinfo_mod(request):
    if request.method == 'GET':
        return render(request, 'userinfo_mod.html')
    if request.method == 'POST':
        newname = request.POST.get('new_name')
        newemail = request.POST.get('new_email')
        newicon = request.POST.get('new_icon')
        userid = request.session.get('user_id')
        user = UserModel.objects.get(pk=userid)
        user.u_name = newname
        user.u_email = newemail
        user.u_icon = newicon
        user.save()
    return  render(request, 'userinfo_mod.html')