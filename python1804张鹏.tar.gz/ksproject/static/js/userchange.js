function user_change() {
    var new_name_color = $("#new_name_info").css('color');
    console.log(new_name_color);

    if (new_name_color === 'rgb(255, 0, 0)') {
        console.log('用户名已存在');
        return false
    }
}
$(function () {
    // 内容改变，且失去焦点
    $("#new_name").change(function () {

        var newname = $(this).val();
        if (newname.length < 6 || newname.length > 30) {
            $("#new_name_info").css('color', 'red').html('用户名长度不能少于6个字或大于15个字');
            return;
        }

        $.getJSON('/axf/checknewname/', {'new_name': newname}, function (data) {
            console.log(data);

            if (data['status'] === '200') {
                console.log('用户名可用');
                $("#new_name_info").html('用户名可用').css('color', 'green');
            } else {
                console.log('用户名已存在');
                $("#new_name_info").html('用户名已存在').css('color', 'red');

            }


        })
    })
})




